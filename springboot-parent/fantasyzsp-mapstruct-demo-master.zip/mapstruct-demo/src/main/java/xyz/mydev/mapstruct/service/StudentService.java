package xyz.mydev.mapstruct.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import xyz.mydev.mapstruct.domain.Student;
import xyz.mydev.mapstruct.dto.StudentDTO;
import xyz.mydev.mapstruct.mapper.StudentMapper;
import xyz.mydev.mapstruct.repository.StudentRepository;

import java.util.List;

/**
 * @author ZSP
 */
@Slf4j
@Service
@Transactional(rollbackFor = Exception.class)
public class StudentService {

  private StudentRepository studentRepository;

  private StudentMapper studentMapper;

  private ObjectMapper objectMapper;


  public StudentService(StudentRepository studentRepository, StudentMapper studentMapper, ObjectMapper objectMapper) {
    this.studentMapper = studentMapper;
    this.studentRepository = studentRepository;
    this.objectMapper = objectMapper;

  }

  public StudentDTO save(StudentDTO StudentDTO) {
    log.debug("service save");
    Student student = studentMapper.toEntity(StudentDTO);
    student = studentRepository.save(student);
    return studentMapper.toDTOs(student);
  }

  public StudentDTO findOne(Long id) {
    Student student = studentRepository.findById(id).orElseThrow();
    return studentMapper.toDTOs(student);
  }

  public List<StudentDTO> findAll() {
    List<Student> listStudents = studentRepository.findAll();
    return studentMapper.toDTOs(listStudents);
  }
}
