package xyz.mydev.mapstruct.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.time.Instant;

/**
 * @author ZSP
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class PersonDTO implements Serializable {
  private Long id;
  private String personName;
  private AddressDTO address;
  private Instant birthday;
}
