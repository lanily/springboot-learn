package xyz.mydev.mapstruct.mapper;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import xyz.mydev.mapstruct.domain.Person;
import xyz.mydev.mapstruct.dto.PersonDTO;

import java.util.List;

/**
 * 引用外部类AddressMapper来对address属性进行映射。mapstruct对检测方法参数与方法进行匹配。
 *
 * @author ZSP
 */
@Mapper(componentModel = "spring", uses = {AddressMapper.class})
@SuppressWarnings("all")
public interface PersonMapper {
  @Mapping(source = "personName", target = "name")
  Person toEntity(PersonDTO personDTO);

  /**
   * Entity和DTO互转时，不必全都标注。使用@InheritInverseConfiguration注解，name指出另一个方法名。
   *
   * @param person entity
   * @return DTO
   * @author ZSP
   */
  @InheritInverseConfiguration(name = "toEntity")
  PersonDTO toDTO(Person person);

  List<PersonDTO> toDTO(List<Person> people);

  List<Person> toEntity(List<PersonDTO> dtos);
}
