package xyz.mydev.mapstruct.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import xyz.mydev.mapstruct.domain.Person;
import xyz.mydev.mapstruct.domain.Student;

/**
 * @author ZSP
 */
public interface StudentRepository extends JpaRepository<Student, Long> {
}
