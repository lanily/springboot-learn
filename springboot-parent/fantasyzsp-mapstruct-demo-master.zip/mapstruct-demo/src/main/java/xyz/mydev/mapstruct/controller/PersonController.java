package xyz.mydev.mapstruct.controller;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import xyz.mydev.mapstruct.dto.PersonDTO;
import xyz.mydev.mapstruct.service.PersonService;

import java.util.List;

/**
 * @author ZSP
 */
@Slf4j
@RestController("/api/person")
public class PersonController {

  private final PersonService personService;

  public PersonController(PersonService personService) {
    this.personService = personService;
  }

  @ApiOperation(value = "创建人物", notes = "根据personDTO对象创建人物")
  @ApiImplicitParam(name = "personDTO", value = "用户详细实体personDTO", required = true, dataType = "personDTO", paramType = "body")
  @PostMapping
  public PersonDTO createPerson(@RequestBody PersonDTO personDTO) {
    log.debug("{}", personDTO);
    return personService.save(personDTO);
  }

  @PutMapping
  public PersonDTO updatePerson(@RequestBody PersonDTO personDTO) {
    if (personDTO.getId() == null) {
      return createPerson(personDTO);
    } else {
      return personService.save(personDTO);
    }
  }

  @GetMapping("/{id}")
  public PersonDTO retrievePerson(@PathVariable Long id) {
    return personService.findOne(id);
  }

  @GetMapping
  public List<PersonDTO> retrieveAllPerson() {
    return personService.findAll();
  }

}
