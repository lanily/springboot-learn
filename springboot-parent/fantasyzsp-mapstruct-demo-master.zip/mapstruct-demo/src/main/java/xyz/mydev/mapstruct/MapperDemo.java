package xyz.mydev.mapstruct;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * @author ZSP
 */
@SpringBootApplication
@EnableSwagger2
public class MapperDemo {
  public static void main(String[] args) {
    SpringApplication.run(MapperDemo.class, args);
  }
}
