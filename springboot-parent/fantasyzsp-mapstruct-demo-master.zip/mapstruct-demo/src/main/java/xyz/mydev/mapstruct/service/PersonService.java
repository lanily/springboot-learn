package xyz.mydev.mapstruct.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import xyz.mydev.mapstruct.domain.Person;
import xyz.mydev.mapstruct.dto.PersonDTO;
import xyz.mydev.mapstruct.mapper.PersonMapper;
import xyz.mydev.mapstruct.repository.PersonRepository;

import java.util.ArrayList;
import java.util.List;

/**
 * @author ZSP
 */
@Slf4j
@Service
@Transactional(rollbackFor = Exception.class)
public class PersonService {

  private PersonRepository personRepository;

  private PersonMapper personMapper;

  private ObjectMapper objectMapper;


  public PersonService(PersonRepository personRepository, PersonMapper personMapper, ObjectMapper objectMapper) {
    this.personMapper = personMapper;
    this.personRepository = personRepository;
    this.objectMapper = objectMapper;

  }

  public PersonDTO save(PersonDTO personDTO) {
    log.debug("service save");
    Person person = personMapper.toEntity(personDTO);
    person = personRepository.save(person);
    return personMapper.toDTO(person);
  }

  public PersonDTO save(String personDTO) {
    log.debug("service String save: {} " + personDTO);
    PersonDTO result = null;
    try {
      result = objectMapper.readValue(personDTO, PersonDTO.class);
      Person person = personMapper.toEntity(result);
      person = personRepository.save(person);
      result = personMapper.toDTO(person);
    } catch (Exception e) {
      log.error("readValue error", e);
      return null;
    }

    return result;
  }

  public PersonDTO findOne(Long id) {
    Person person = personRepository.findById(id).orElseThrow();
    return personMapper.toDTO(person);
  }

  public List<PersonDTO> findAll() {
    List<Person> listPersons = personRepository.findAll();
    return personMapper.toDTO(listPersons);
  }
}
