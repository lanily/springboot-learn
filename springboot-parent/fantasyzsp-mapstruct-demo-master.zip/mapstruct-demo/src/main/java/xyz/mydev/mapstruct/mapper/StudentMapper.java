package xyz.mydev.mapstruct.mapper;

import org.mapstruct.Mapper;
import xyz.mydev.mapstruct.domain.Person;
import xyz.mydev.mapstruct.domain.Student;
import xyz.mydev.mapstruct.dto.PersonDTO;
import xyz.mydev.mapstruct.dto.StudentDTO;

/**
 * @author ZSP
 */
@Mapper(componentModel = "spring", uses = {AddressMapper.class})
public interface StudentMapper extends BaseMapper<Student, StudentDTO> {
}
