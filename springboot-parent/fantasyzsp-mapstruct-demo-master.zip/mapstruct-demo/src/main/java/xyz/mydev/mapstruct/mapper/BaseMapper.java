package xyz.mydev.mapstruct.mapper;

import java.util.List;

/**
 * T entity
 * D dto
 *
 * @author ZSP  2019/09/03 09:32
 */
public interface BaseMapper<T, D> {
  D toDTOs(T t);

  T toEntity(D d);

  List<D> toDTOs(List<T> t);

  List<T> toEntities(List<D> d);
}
