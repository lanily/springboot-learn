package xyz.mydev.mapstruct.mapper;

import org.mapstruct.Mapper;
import xyz.mydev.mapstruct.domain.Person;
import xyz.mydev.mapstruct.domain.Student;
import xyz.mydev.mapstruct.dto.PersonDTO;
import xyz.mydev.mapstruct.dto.StudentDTO;

/**
 * 引用外部类AddressMapper来对address属性进行映射。mapstruct对检测方法参数与方法进行匹配。
 *
 * @author ZSP
 */
@Mapper(componentModel = "spring", uses = {AddressMapper.class})
public interface PersonMapper2 extends BaseMapper<Person, PersonDTO> {
  StudentDTO toDTO(Student entity);
}
