# Spring Demo

This project serves both as:
 * a series of boilerplate projects 
 * supporting material for tutorials

Each `feature` branch is a typical feature branch and each `project` branch is a self-contained boilerplate project.