/**
 * 
 */
package rs.in.staleksit.demo.jersey2.model.manufacturer;

/**
 *
 */
public interface Manufacturer {
	
	Integer getId();
	
	void setId(Integer id);
	
	String getName();
	
	void setName(String name);
	
	boolean isActive();

}
