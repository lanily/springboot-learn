Sample REST service demonstrating asynchronous processing build on Spring Boot and Jersey 2. Requires Java 8, build with gradle 2.1.

