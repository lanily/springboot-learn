# SpringBootJerseyAppTests   

Spring Boot JAX-RS EasyMock Mockito  

