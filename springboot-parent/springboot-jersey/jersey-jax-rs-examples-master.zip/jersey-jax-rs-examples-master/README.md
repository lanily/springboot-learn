# Jersey (JAX-RS) examples project
----

This Project consists of several examples/samples for Jersey (JAX-RS) features.

This is a companion projects for [Jersey (JAX-RS) guides](http://www.geekmj.org/guides/jersey-restful-web-services-development-guides-196/) on [GeekMJ website](https://www.geekmj.org).

You can read getting started guide [here](http://www.geekmj.org/jersey/jersey-spring-boot-quick-starter-guide-198/).
