# "Caching Still Matters" conference demos

This repository contains the code for the demos done during the "Caching Still Matters" conference.

## Demos

- 'JvmCaching' - demonstrate that the JDK uses a cache to store frequently used integers
