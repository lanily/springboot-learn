/**
 * Data Transfer Objects.
 */
package org.ehcache.sample.service.dto;
