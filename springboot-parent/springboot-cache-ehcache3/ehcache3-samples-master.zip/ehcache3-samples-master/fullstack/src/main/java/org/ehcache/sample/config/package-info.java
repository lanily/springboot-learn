/**
 * Spring Framework configuration files.
 */
package org.ehcache.sample.config;
