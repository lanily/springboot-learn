/**
 * Audit specific code.
 */
package org.ehcache.sample.config.audit;
