/**
 * Service layer beans.
 */
package org.ehcache.sample.service;
