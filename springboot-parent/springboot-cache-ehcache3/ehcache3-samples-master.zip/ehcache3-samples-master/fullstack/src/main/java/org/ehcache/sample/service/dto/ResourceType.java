package org.ehcache.sample.service.dto;

/**
 * @author Henri Tremblay
 */
public enum ResourceType {

    WEB_SERVICE, DATABASE
}
