/**
 * Spring Security configuration.
 */
package org.ehcache.sample.security;
