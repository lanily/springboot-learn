/**
 * View Models used by Spring MVC REST controllers.
 */
package org.ehcache.sample.web.rest.vm;
