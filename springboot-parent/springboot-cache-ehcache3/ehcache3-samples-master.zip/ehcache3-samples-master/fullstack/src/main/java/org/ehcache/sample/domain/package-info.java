/**
 * JPA domain objects.
 */
package org.ehcache.sample.domain;
