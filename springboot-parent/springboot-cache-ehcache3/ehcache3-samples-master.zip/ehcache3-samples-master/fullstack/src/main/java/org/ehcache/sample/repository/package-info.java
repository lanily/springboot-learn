/**
 * Spring Data JPA repositories.
 */
package org.ehcache.sample.repository;
