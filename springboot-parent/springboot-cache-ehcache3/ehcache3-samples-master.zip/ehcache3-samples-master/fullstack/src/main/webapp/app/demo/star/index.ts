export * from './star.model';
export * from './star.service';
export * from './star-detail.component';
export * from './star.component';
export * from './star.route';
