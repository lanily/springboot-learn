export * from './actor.service';
export * from './actor-update.component';
export * from './actor-delete-dialog.component';
export * from './actor-detail.component';
export * from './actor.component';
export * from './actor.route';
