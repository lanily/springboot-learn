# Ehcache 3 Scale Continuum

This sample demonstrates how Ehcache helps scaling.

Start the `org.terracotta.sample.Main` class with JDK 8+ and open a browser on [http://localhost:4567](http://localhost:4567) 
to access the controls.

You can do that with

`mvn verify -Prun`

or 

`mvn package exec:java`

or

`mvn package && java -jar target/scale-continuum-*.jar`
